
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;
import javax.persistence.*;
import java.util.List;

@SpringBootApplication
public class BackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(BackendApplication.class, args);
    }
}

@Entity
class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private Double price;
    
    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }
}

interface ProductRepository extends JpaRepository<Product, Long> {}

@Service
class ProductService {
    @Autowired
    private ProductRepository repository;
    
    public List<Product> getAllProducts() { return repository.findAll(); }
    public Product addProduct(Product product) { return repository.save(product); }
}

@RestController
@RequestMapping("/api/products")
class ProductController {
    @Autowired
    private ProductService service;
    
    @GetMapping
    public List<Product> getAllProducts() { return service.getAllProducts(); }
    
    @PostMapping
    public Product addProduct(@RequestBody Product product) { return service.addProduct(product); }
}
